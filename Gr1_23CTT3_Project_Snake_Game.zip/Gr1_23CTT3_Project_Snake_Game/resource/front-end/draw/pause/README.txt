- Title: 18 11 240 ( 240 là mã màu )
- resume:
	+ button: 19 18
	+ button_click: 19 18
	+ resume xanh: 26 19 176
	+ resume vàng: 26 19 224
- save:
	+ button: 19 26
	+ button_click: 19 26
	+ save xanh: 31 27 176
	+ save vàng: 31 27 224
- exit:
	+ button: 19 34
	+ button_click: 19 34
	+ exit xanh: 31 35 176
	+ exit vàng: 31 35 224
