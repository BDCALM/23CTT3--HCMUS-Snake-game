x là 57, y là 72, màu 244 để thành chữ đỏ trên nền trắng
= = = PRESS [ENTER] TO CONTINUE = = =